<?php

namespace App\Controller;

class ErrorController
{

}
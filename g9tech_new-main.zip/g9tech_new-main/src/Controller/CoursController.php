<?php

namespace App\Controller;

use App\Entity\Cours;
use App\Repository\CategoryRepository;
use App\Service\CoursService;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class CoursController extends AbstractController
{
    #[Route('/cours', name: 'app_cours_index')]
    public function affiche(CoursService $coursService, CategoryRepository $categoryRepository): Response
    {
        return $this->render('cours/affiche.html.twig', [
            'courses' => $coursService->getPaginatedCours(),
            'categories' => $categoryRepository->findAll()
        ]);
    }

    #[Route('/cours/{slug}', name: 'app_cours')]
    public function index(?Cours $cours): Response
    {
        if (!$cours) {
            return $this->redirectToRoute('app_home');
        }

        return $this->render('cours/index.html.twig', [
            'cours' => $cours
        ]);
    }
}

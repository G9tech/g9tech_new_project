<?php

namespace App\Service;

use App\Entity\Category;
use App\Repository\CoursRepository;
use Knp\Component\Pager\Pagination\PaginationInterface;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Component\HttpFoundation\RequestStack;

class CoursService
{
    public function __construct(
        private readonly RequestStack    $requestStack,
        private readonly CoursRepository $coursRepository,
        private readonly PaginatorInterface $paginator,
        private readonly OptionService $optionService
    ){}

    public function getPaginatedCours(?Category $category = null): PaginationInterface
    {
        $request = $this->requestStack->getMainRequest();
        $page = $request->query->getInt('page', 1);
        $limit = $this->optionService->getValue('cours_limit');

        $coursQuery = $this->coursRepository->findForPagination($category);

        return $this->paginator->paginate($coursQuery, $page, $limit);
    }
}
<?php

namespace App\Twig;

use App\Entity\Menu;
use EasyCorp\Bundle\EasyAdminBundle\Router\AdminUrlGenerator;
use Symfony\Component\Routing\RouterInterface;
use Twig\Extension\AbstractExtension;
use Twig\TwigFilter;
use Twig\TwigFunction;

class g9TechExtension extends AbstractExtension
{
    const ADMIN_NAMESPACE = 'App\Controller\Admin';

    public function __construct(
        private readonly RouterInterface $router,
        private readonly AdminUrlGenerator $adminUrlGenerator
    ){}

    public function getFilters(): array
    {
        return [
          new TwigFilter('menuLink', [$this, 'menuLink']),
        ];
    }

    public function getFunctions(): array
    {
        return [
            new TwigFunction('ea_index', [$this, 'getG9techUrl']),
        ];
    }

    public function getG9techUrl(string $controller, ?string $action = null): string
    {
        $adminGenerator = $this->adminUrlGenerator
            ->setController(self::ADMIN_NAMESPACE . DIRECTORY_SEPARATOR . $controller);

        if ($action) {
            $adminGenerator->setAction($action);
        }

        return $adminGenerator->generateUrl();
    }

    public function menuLink(Menu $menu): string
    {
        $cours = $menu->getCourse();
        $category = $menu->getCategory();
        $page = $menu->getPage();

        $url = $menu->getLink() ?: '#';

        if ($url != '#') {
            return $url;
        }

        if ($category) {
            $name = 'app_category';
            $slug = $category->getSlug();
        }

        if ($page) {
            $name = 'app_page';
            $slug = $page->getSlug();
        }

        if ($cours) {
            $name = 'app_cours';
            $slug = $cours->getSlug();
        }

        if (!isset($name, $slug)) {
            return $url;
        }

        return $this->router->generate($name, [
            'slug' => $slug
        ]);
    }
}